  /**
  ******************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WLxx devices support on EWARM.
  ***********************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32WLxx 
  devices by EWARM8 and laters.

 1. If you have already installed an STM32WL patch before, you can remove it by running 
  Uninstall_Patch.bat (run as administrator).

 2. Running the "EWARMv8_STM32WLxx_Support_V4.7.exe" adds the following:
   - Dual Core (M4 & M0+) lines: STM32WL54xx/WL55xx
   - Single Core (M4) lines: STM32WLE4xx/WLE5xx
   - Automatic STM32WLxx flash algorithm selection
   - files (.mac, .boards, .flash) for secure flashloader whe ESE=1
   - SVD file 


 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx 
 or later installed. 
 You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32WLxx_Support_V4.7.exe"  at EWARM install directory.
 EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
 please change it manually if you have EWARM installed at different location.

 1. open EWARM IDE
 2. From Project Options> General Options> Target > Device, select the required STM32WL
 3. The corresponding flashloader will be invoked automatically

If the Hardwware Option byte ESE=1, you need to change the default flashloader and point to the secure one.
You can simply override the default flashloader from the debug options as follows:
 1. From From Project Options> General Options> Debugger> Download>, check the option "Override defualt.board file
 2. Browse in IAR insatll directory and select [IAR Systems]\Embedded Workbench 8.xx\arm\config\flashloader\ST\FlashSTM32WL_SEC.board
 This flashloader will allow the programming via JTAG/SWD Interface


******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE************************





	



