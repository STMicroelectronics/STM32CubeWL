  /**
  ***********************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WLxx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32WLxx 
  devices by EWARM8 and laters.

 1. If you have already installed an STM32WL patch before, you can remove it by running 
  Uninstall_Patch.bat (run as administrator).

 2. Running the "EWARMv8_STM32WLxx_V4.9.exe" Signed patch adds the following:
 ===================================================================
   - Dual Core (M4 & M0+) lines: STM32WL54xx/WL55xx/WL5Mxx
   - Single Core (M4) lines: STM32WLE4xx/WLE5xx
   - Automatic STM32WLxx flash algorithm selection
   - files (.mac, .boards, .flash) for secure flashloader when ESE=1
   - STM32WLx SVD file 

 PS: when using external loader on EWARM, please unselect the verify from the debug menu

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have EWARM v8.xx 
 or later installed. 
 You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv8_STM32WLxx_V4.9.exe"  at EWARM install directory.
 EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
 please change it manually if you have EWARM installed at different location.

 1. open EWARM IDE
 2. From Project Options> General Options> Target > Device, select the required STM32WL
 3. The corresponding flashloader will be invoked automatically

 * If the Hardwware Option byte ESE=1, you need to change the default flashloader and point to the secure one.
 You can simply override the default flashloader from the debug options as follows:
 1. From From Project Options> General Options> Debugger> Download>, check the option "Override default.board file
 2. Browse in IAR insatll directory and select [IAR Systems]\Embedded Workbench 8.xx\arm\config\flashloader\ST\FlashSTM32WL_SEC.board
 This flashloader will allow the programming via JTAG/SWD Interface.








	



